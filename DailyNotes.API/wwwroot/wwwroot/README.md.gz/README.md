# User Documentation
<br>

## Register
<br>

1. Click Register
2. Fill out Form
3. Click Register

## Login
<br> 

1. Click Login
2. Fill in Email and Password
3. Click Login

## Create Entry
<br>

1. Click Create Entry or Daily Prompt
2. Fill in Title
3. Enter Entry text into text box
4. If you want others to be able to see your entry, click public
5. Click Create Entry

## Edit Entry
<br>

1. Click on my Entries
2. Make changes
3. Save Entry

## Delete Entry
<br> 

1. Go to My Entries
2. CLick Delete on the Entry you want to delete
